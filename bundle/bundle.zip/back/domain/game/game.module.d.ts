export default class GameModule {
}
