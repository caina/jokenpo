export declare enum Jokenpo {
    PAPER = "PAPER",
    ROCK = "ROCK",
    SCISSOR = "SCISSOR"
}
export declare class Move {
    isConn: boolean | undefined;
    move?: Jokenpo;
    win: boolean | null;
    constructor(raw?: Partial<Move>);
}
