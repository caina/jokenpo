import { GamebotService } from './gamebot.service';
import { Move } from '../dto';
import { Jokenpo } from '../dto';
export declare class GameService {
    private gameBot;
    constructor(gameBot: GamebotService);
    rules: {
        ROCK: Jokenpo[];
        PAPER: Jokenpo[];
        SCISSOR: Jokenpo[];
    };
    playerGame(playerMove: Move): Promise<Move[]>;
    autoPlay(): Promise<Move[]>;
    private applyRules;
}
