import { Move } from '../dto';
import { Jokenpo } from '../dto';
export declare class GamebotService {
    makeMove(): Move;
    randomMove(): Jokenpo;
}
