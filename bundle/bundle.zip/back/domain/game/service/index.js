"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.services = void 0;
const gamebot_service_1 = require("./gamebot.service");
const game_service_1 = require("./game.service");
exports.services = [gamebot_service_1.GamebotService, game_service_1.GameService];
//# sourceMappingURL=index.js.map