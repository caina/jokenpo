import { GamebotService } from './gamebot.service';
import { GameService } from './game.service';
export declare const services: (typeof GamebotService | typeof GameService)[];
