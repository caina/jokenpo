"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GamebotService = void 0;
const common_1 = require("@nestjs/common");
const dto_1 = require("../dto");
const dto_2 = require("../dto");
let GamebotService = class GamebotService {
    makeMove() {
        const move = this.randomMove();
        return new dto_1.Move({
            isConn: true,
            move,
        });
    }
    randomMove() {
        const random = Math.floor(Math.random() * Object.keys(dto_2.Jokenpo).length);
        const selected = Object.values(dto_2.Jokenpo)[random];
        return dto_2.Jokenpo[selected];
    }
};
GamebotService = __decorate([
    (0, common_1.Injectable)()
], GamebotService);
exports.GamebotService = GamebotService;
//# sourceMappingURL=gamebot.service.js.map