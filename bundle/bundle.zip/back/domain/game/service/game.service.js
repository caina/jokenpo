"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameService = void 0;
const common_1 = require("@nestjs/common");
const common_2 = require("@nestjs/common");
const gamebot_service_1 = require("./gamebot.service");
const dto_1 = require("../dto");
let GameService = class GameService {
    constructor(gameBot) {
        this.gameBot = gameBot;
        this.rules = {
            [dto_1.Jokenpo.ROCK]: [dto_1.Jokenpo.SCISSOR],
            [dto_1.Jokenpo.PAPER]: [dto_1.Jokenpo.ROCK],
            [dto_1.Jokenpo.SCISSOR]: [dto_1.Jokenpo.PAPER],
        };
    }
    async playerGame(playerMove) {
        const botMove = this.gameBot.makeMove();
        playerMove.win = this.applyRules(playerMove.move, botMove.move);
        botMove.win = this.applyRules(botMove.move, playerMove.move);
        return [playerMove, botMove];
    }
    async autoPlay() {
        const botMove = this.gameBot.makeMove();
        const botMove2 = this.gameBot.makeMove();
        botMove.win = this.applyRules(botMove.move, botMove2.move);
        botMove2.win = this.applyRules(botMove2.move, botMove.move);
        return [botMove, botMove2];
    }
    applyRules(challenger, challenged) {
        return this.rules[challenger].includes(challenged);
    }
};
GameService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_2.Inject)(gamebot_service_1.GamebotService)),
    __metadata("design:paramtypes", [gamebot_service_1.GamebotService])
], GameService);
exports.GameService = GameService;
//# sourceMappingURL=game.service.js.map