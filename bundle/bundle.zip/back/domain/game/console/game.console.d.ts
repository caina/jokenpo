import { CommandArguments } from '@squareboat/nest-console';
import { GameService } from '../service/game.service';
export declare class GameConsole {
    private game;
    static messages: {
        wrong_input: string;
        win: string;
        lose: string;
        tie: string;
    };
    constructor(game: GameService);
    bet(args: CommandArguments): Promise<void>;
    auto(): Promise<void>;
}
