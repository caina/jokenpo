"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var GameConsole_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameConsole = void 0;
const common_1 = require("@nestjs/common");
const nest_console_1 = require("@squareboat/nest-console");
const nest_console_2 = require("@squareboat/nest-console");
const dto_1 = require("../dto");
const game_service_1 = require("../service/game.service");
const common_2 = require("@nestjs/common");
const dto_2 = require("../dto");
let GameConsole = GameConsole_1 = class GameConsole {
    constructor(game) {
        this.game = game;
    }
    async bet(args) {
        const move = dto_1.Jokenpo[args.move];
        if (move === undefined) {
            nest_console_2._cli.error(GameConsole_1.messages.wrong_input);
            return;
        }
        const results = await this.game.playerGame(new dto_2.Move({
            isConn: false,
            move,
        }));
        if (results.filter((it) => it.win).length === 0) {
            nest_console_2._cli.info(GameConsole_1.messages.tie);
            return;
        }
        if (results.find((it) => it.isConn == false && it.win)) {
            nest_console_2._cli.success(GameConsole_1.messages.win);
            return;
        }
        nest_console_2._cli.error(GameConsole_1.messages.lose);
        return;
    }
    async auto() {
        const result = await this.game.autoPlay();
        if (result.filter((it) => it.win).length === 0) {
            nest_console_2._cli.info(GameConsole_1.messages.tie);
            return;
        }
        result.forEach((bot, index) => {
            if (bot.win) {
                nest_console_2._cli.success(`bot0${index + 1} win with ${bot.move}`);
            }
            else {
                nest_console_2._cli.error(`bot0${index + 1} lose with ${bot.move}`);
            }
        });
    }
};
GameConsole.messages = {
    wrong_input: "Bet should be 'ROCK', 'PAPER' OR SCISSOR",
    win: 'You win!',
    lose: 'You lose',
    tie: 'Its a tie!',
};
__decorate([
    (0, nest_console_1.Command)('bet', {
        desc: 'Bet on Rock, Scissor or Paper against machine',
        args: { move: { req: true } },
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], GameConsole.prototype, "bet", null);
__decorate([
    (0, nest_console_1.Command)('auto', {
        desc: 'auto bet',
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], GameConsole.prototype, "auto", null);
GameConsole = GameConsole_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_2.Inject)(game_service_1.GameService)),
    __metadata("design:paramtypes", [game_service_1.GameService])
], GameConsole);
exports.GameConsole = GameConsole;
//# sourceMappingURL=game.console.js.map