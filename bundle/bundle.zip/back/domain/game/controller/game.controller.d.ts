import { Move } from '../dto';
import { GameService } from '../service/game.service';
export declare class GameController {
    private game;
    constructor(game: GameService);
    bet(move: Move): Promise<Move[]>;
    auto(): Promise<Move[]>;
}
