"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameController = void 0;
const common_1 = require("@nestjs/common");
const common_2 = require("@nestjs/common");
const common_3 = require("@nestjs/common");
const common_4 = require("@nestjs/common");
const common_5 = require("@nestjs/common");
const common_6 = require("@nestjs/common");
const common_7 = require("@nestjs/common");
const dto_1 = require("../dto");
const game_service_1 = require("../service/game.service");
let GameController = class GameController {
    constructor(game) {
        this.game = game;
    }
    async bet(move) {
        return this.game.playerGame(move);
    }
    async auto() {
        return this.game.autoPlay();
    }
};
__decorate([
    (0, common_3.HttpCode)(200),
    (0, common_2.Post)(),
    (0, common_6.UsePipes)(new common_7.ValidationPipe({ transform: true })),
    __param(0, (0, common_5.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dto_1.Move]),
    __metadata("design:returntype", Promise)
], GameController.prototype, "bet", null);
__decorate([
    (0, common_3.HttpCode)(200),
    (0, common_2.Post)('/auto'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], GameController.prototype, "auto", null);
GameController = __decorate([
    (0, common_1.Controller)('api/bet'),
    __param(0, (0, common_4.Inject)(game_service_1.GameService)),
    __metadata("design:paramtypes", [game_service_1.GameService])
], GameController);
exports.GameController = GameController;
//# sourceMappingURL=game.controller.js.map